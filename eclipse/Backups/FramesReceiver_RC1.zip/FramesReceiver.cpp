/*
 * FramesReceiver.cpp
 *
 *  Created on: 28 ���� 2014
 *      Author: benny
 */

#include "FramesReceiver.h"

#include <opencv2/opencv.hpp>

FramesReceiver::FramesReceiver()
{
	_captureSource = NULL;
	_image = NULL;
}

FramesReceiver::~FramesReceiver()
{
	cvReleaseCapture(&_captureSource);
	cvDestroyWindow("Display window");
}


bool FramesReceiver::LoadCamera(int source)
{
	_captureSource = cvCreateCameraCapture(source);
	return _captureSource != NULL;
}

bool FramesReceiver::LoadVideo(char * URL)
{
	_captureSource = cvCaptureFromFile(URL);
	return _captureSource != NULL;
}

bool FramesReceiver::GetFrameInfo(int & imageWidth, int & imageHeight, int & imageBPP)
{
	imageWidth = imageHeight = imageBPP = 0;

	if(_captureSource)
	{
		//imageWidth  = cvGetCaptureProperty(_captureSource, CV_CAP_PROP_FRAME_WIDTH);
		//imageHeight = cvGetCaptureProperty(_captureSource, CV_CAP_PROP_FRAME_HEIGHT);

		while (_image == NULL)
			_image = cvQueryFrame(_captureSource);

		imageWidth  = _image -> width;
		imageHeight = _image -> height;
		imageBPP    = _image -> nChannels * 8;
	}

	return imageWidth != 0 && imageHeight != 0 && imageBPP != 0;
}

bool FramesReceiver::IsFrameFready()
{
	_image = cvQueryFrame(_captureSource);
	return _image != NULL;
}

char * FramesReceiver::ReceiveFrame()
{
	if (_image)
		return _image -> imageData;
	return NULL;
}

void FramesReceiver::Show()
{
//	void * hWnd = cvGetWindowHandle("Display window");
//	if (!hWnd)
//		cvNamedWindow("Display window", CV_WINDOW_AUTOSIZE | CV_GUI_NORMAL);// Create a window for display.

	cvShowImage("Display window", _image);

	cvWaitKey(1);	// needed to repaint the window
}