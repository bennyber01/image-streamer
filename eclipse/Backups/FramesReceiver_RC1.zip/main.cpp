/*
 * main.cpp
 *
 *  Created on: 28 ���� 2014
 *      Author: benny
 */

#include "FramesReceiver.h"
#include "bitmap_image.hpp"
#include <stdio.h>

#include <opencv2/highgui/highgui.hpp>  // cvWaitKey

int main()
{
	char * URL = "rtsp://a2047.v1411b.c1411.g.vq.akamaistream.net/5/2047/1411/1_h264_650/1a1a1ae454c430950065de4cbb2f94c226950c7ae655b61a48a91475e243acda3dac194879adde0f/080690210abcn_2a_650.mov";

	FramesReceiver framesReceiver;

	int imageWidth;
	int imageHeight;
	int imageBPP;

	framesReceiver.LoadVideo(URL);

	framesReceiver.GetFrameInfo(imageWidth, imageHeight, imageBPP);

	char * buff = NULL;

	while(cvWaitKey(10) != atoi("q"))
	{
		while (framesReceiver.IsFrameFready())
		{
			buff = framesReceiver.ReceiveFrame();

			if (1)
				framesReceiver.Show();
			else
			{
				// save image on HDD
				bitmap_image image(imageWidth, imageHeight);
				int sizeToCopy = sizeof(char) * imageWidth * imageHeight * imageBPP / 8;
				std::copy(buff, buff + sizeToCopy, image.data());
				char filePath[200];
				static int imageCounter = 0;
				_snprintf_s(filePath, sizeof(filePath), "D:/eclipse_workspace/FramesReceiver/ReceivedFrames/img%04d.bmp", imageCounter++);
				image.save_image(filePath);
			}
		}
	}

	return 0;
}


