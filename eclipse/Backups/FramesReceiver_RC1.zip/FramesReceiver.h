/*
 * FramesReceiver.h
 *
 *  Created on: 28 ���� 2014
 *      Author: benny
 */

#ifndef FRAMESRECEIVER_H_
#define FRAMESRECEIVER_H_

#include "FramesReceiverInterface.h"
#include <opencv2/core/types_c.h>

struct CvCapture;

class FramesReceiver: public FramesReceiverInterface
{
public:
	FramesReceiver();
	~FramesReceiver();

	bool IsFrameFready();
	char * ReceiveFrame();

	bool LoadVideo(char * URL);
	bool LoadCamera(int source);

	bool GetFrameInfo(int & imageWidth, int & imageHeight, int & imageBPP);

	void Show();

private:
	CvCapture * _captureSource;
	IplImage * _image;
};

#endif /* FRAMESRECEIVER_H_ */
